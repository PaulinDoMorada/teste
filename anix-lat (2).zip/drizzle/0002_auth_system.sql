-- Migration: Update users table for custom authentication system
-- Add new columns
ALTER TABLE `users` ADD COLUMN `password` varchar(255) NOT NULL DEFAULT '';
ALTER TABLE `users` ADD COLUMN `avatar` text;

-- Make email NOT NULL and add unique constraint if not exists
ALTER TABLE `users` MODIFY COLUMN `email` varchar(320) NOT NULL;
ALTER TABLE `users` MODIFY COLUMN `name` varchar(255) NOT NULL DEFAULT '';

-- Drop old OAuth columns
ALTER TABLE `users` DROP COLUMN `openId`;
ALTER TABLE `users` DROP COLUMN `loginMethod`;
