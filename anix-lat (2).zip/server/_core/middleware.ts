import { Request, Response, NextFunction } from "express";
import * as admin from "../admin";

// Middleware para registrar acessos
export async function logAccessMiddleware(req: Request, res: Response, next: NextFunction) {
  try {
    const ipAddress = req.ip || req.socket.remoteAddress || "unknown";
    const path = req.path;
    const userAgent = req.headers["user-agent"];
    const referer = req.headers["referer"];

    // Não logar acessos a assets estáticos
    if (!path.startsWith("/api") && !path.startsWith("/@") && !path.includes(".")) {
      await admin.logAccess({
        ipAddress,
        path,
        userAgent,
        referer,
        timestamp: Date.now(),
      });
    }
  } catch (error) {
    console.error("[Middleware] Error logging access:", error);
  }
  
  next();
}

// Middleware para verificar IPs banidos
export async function checkBannedIpMiddleware(req: Request, res: Response, next: NextFunction) {
  try {
    const ipAddress = req.ip || req.socket.remoteAddress || "unknown";
    
    // Permitir acesso ao admin login mesmo se banido (para desbanir)
    if (req.path === "/admin/login" || req.path.startsWith("/api/trpc/admin.login")) {
      return next();
    }

    const isBanned = await admin.isIpBanned(ipAddress);
    
    if (isBanned) {
      return res.status(403).send(`
        <!DOCTYPE html>
        <html lang="pt-BR">
        <head>
          <meta charset="UTF-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
          <title>Acesso Bloqueado - ANIX-LAT</title>
          <style>
            body {
              margin: 0;
              padding: 0;
              font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
              background: linear-gradient(135deg, #1a1a1a 0%, #000000 100%);
              color: white;
              display: flex;
              align-items: center;
              justify-center;
              min-height: 100vh;
            }
            .container {
              text-align: center;
              padding: 2rem;
              max-width: 600px;
            }
            .icon {
              font-size: 4rem;
              margin-bottom: 1rem;
            }
            h1 {
              font-size: 2.5rem;
              margin-bottom: 1rem;
              color: #ef4444;
            }
            p {
              font-size: 1.1rem;
              color: #9ca3af;
              line-height: 1.6;
            }
            .ip {
              font-family: monospace;
              background: rgba(255, 255, 255, 0.1);
              padding: 0.5rem 1rem;
              border-radius: 0.5rem;
              display: inline-block;
              margin-top: 1rem;
            }
          </style>
        </head>
        <body>
          <div class="container">
            <div class="icon">🚫</div>
            <h1>Acesso Bloqueado</h1>
            <p>Seu endereço IP foi banido devido a violações das políticas de uso do site.</p>
            <p>Se você acredita que isso é um erro, entre em contato com o administrador.</p>
            <div class="ip">IP: ${ipAddress}</div>
          </div>
        </body>
        </html>
      `);
    }
    
    next();
  } catch (error) {
    console.error("[Middleware] Error checking banned IP:", error);
    next();
  }
}

// Middleware para verificar modo manutenção
export async function checkMaintenanceModeMiddleware(req: Request, res: Response, next: NextFunction) {
  try {
    // Permitir acesso ao admin mesmo em modo manutenção
    if (req.path.startsWith("/admin") || req.path.startsWith("/api/trpc/admin")) {
      return next();
    }

    const isMaintenanceMode = await admin.isMaintenanceMode();
    
    if (isMaintenanceMode) {
      const message = await admin.getMaintenanceMessage();
      
      return res.status(503).send(`
        <!DOCTYPE html>
        <html lang="pt-BR">
        <head>
          <meta charset="UTF-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
          <title>Manutenção - ANIX-LAT</title>
          <style>
            body {
              margin: 0;
              padding: 0;
              font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
              background: linear-gradient(135deg, #1a1a1a 0%, #000000 100%);
              color: white;
              display: flex;
              align-items: center;
              justify-center;
              min-height: 100vh;
            }
            .container {
              text-align: center;
              padding: 2rem;
              max-width: 600px;
            }
            .logo {
              font-size: 3rem;
              font-weight: bold;
              color: #ef4444;
              margin-bottom: 2rem;
            }
            .icon {
              font-size: 4rem;
              margin-bottom: 1rem;
            }
            h1 {
              font-size: 2.5rem;
              margin-bottom: 1rem;
            }
            p {
              font-size: 1.1rem;
              color: #9ca3af;
              line-height: 1.6;
            }
            .spinner {
              border: 4px solid rgba(255, 255, 255, 0.1);
              border-left-color: #ef4444;
              border-radius: 50%;
              width: 50px;
              height: 50px;
              animation: spin 1s linear infinite;
              margin: 2rem auto;
            }
            @keyframes spin {
              to { transform: rotate(360deg); }
            }
          </style>
        </head>
        <body>
          <div class="container">
            <div class="logo">ANIX-LAT</div>
            <div class="icon">🔧</div>
            <h1>Site em Manutenção</h1>
            <p>${message}</p>
            <div class="spinner"></div>
            <p style="font-size: 0.9rem; margin-top: 2rem;">Agradecemos sua compreensão.</p>
          </div>
        </body>
        </html>
      `);
    }
    
    next();
  } catch (error) {
    console.error("[Middleware] Error checking maintenance mode:", error);
    next();
  }
}
