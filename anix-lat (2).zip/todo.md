# ANIX-LAT - TODO List

## 1. Botões de Navegação Permanentes
- [x] Remover botão temporário que aparece nos últimos 10 segundos
- [x] Adicionar botão "Próximo Episódio" (se houver)
- [x] Posicionar abaixo do player, sempre visível
- [x] Design consistente com o resto do site
- [x] API não fornece previousEpisodeID, apenas nextEpisodeID

## 2. Seção de Informações do Anime
- [x] Sinopse completa do anime
- [x] Gêneros (badges)
- [x] Data de lançamento
- [x] Classificação etária
- [x] Dia de lançamento
- [x] Número total de episódios
- [x] Layout organizado e responsivo

## 3. Painel de Administração (/admin)

### 3.1 Autenticação Admin
- [x] Sistema de login seguro (credenciais criptografadas no backend)
- [x] Sessão admin com JWT
- [x] Rate limiting para tentativas de login
- [x] Sistema de banimento automático por IP (após múltiplas tentativas falhas)
- [x] Middleware de proteção para rotas admin

### 3.2 Sistema de Notificações
- [x] Enviar notificações broadcast para todos os usuários
- [x] Notificações aparecem no ícone do sininho (Navbar)
- [x] Armazenar notificações no banco de dados
- [x] Dropdown de notificações no frontend

### 3.3 Modo Manutenção
- [x] Toggle para ativar/desativar modo manutenção
- [x] Página de manutenção personalizada
- [x] Middleware que bloqueia acesso ao site (exceto admin)
- [x] Mensagem customizável de manutenção

### 3.4 Sistema de Avisos
- [x] Criar avisos que aparecem em dialog na home
- [x] CRUD de avisos (criar, editar, deletar)
- [x] Avisos com título, mensagem e tipo (info/warning/error/success)
- [x] Controle de visibilidade dos avisos

### 3.5 Logs de Acesso
- [x] Registrar acessos ao site (IP, página, timestamp, user agent)
- [x] Dashboard de logs em tempo real
- [x] Estatísticas de acesso (páginas mais visitadas, IPs únicos, visitas 24h)

### 3.6 Sistema de Banimento
- [x] Lista de IPs banidos no banco de dados
- [x] Middleware que bloqueia IPs banidos
- [x] Interface para gerenciar banimentos (adicionar/remover)
- [x] Banimento automático após 5 tentativas de login falhas em 15 minutos

### 3.7 Dashboard Admin
- [x] Página /admin com layout profissional
- [x] Seção de notificações broadcast
- [x] Seção de modo manutenção
- [x] Seção de avisos
- [x] Seção de logs de acesso
- [x] Seção de gerenciamento de banimentos
- [x] Estatísticas gerais do site

## 4. Correções de Bugs

### 4.1 Sistema de Cookies Admin
- [x] Instalar cookie-parser no Express
- [x] Configurar middleware de cookies antes das rotas
- [x] Corrigir acesso a ctx.req.cookies no backend

### 4.2 Verificação de Sessão Admin
- [x] verifySession deve ser publicProcedure (não adminProcedure)
- [x] Permitir verificação de sessão sem token (retornar isValid: false)
- [x] Adicionar enabled: false para queries admin quando não autenticado

### 4.3 Middlewares de Manutenção e Banimento
- [x] Corrigir carregamento infinito quando modo manutenção está ativo
- [x] Corrigir carregamento infinito quando IP está banido
- [x] Garantir que middlewares assíncronos funcionem corretamente
- [x] Remover next() duplo após enviar resposta HTML
