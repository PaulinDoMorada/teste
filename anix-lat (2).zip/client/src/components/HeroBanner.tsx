import { Play, Info } from "lucide-react";
import { Link } from "wouter";
import { Button } from "./ui/button";

interface HeroBannerProps {
  animeId: number;
  title: string;
  description: string;
  banner: string;
  tags?: string;
  year?: string;
  rating?: string;
  episodeId?: number;
}

export default function HeroBanner({
  animeId,
  title,
  description,
  banner,
  tags,
  year,
  rating,
  episodeId,
}: HeroBannerProps) {
  return (
    <div className="relative h-[70vh] w-full overflow-hidden">
      <div className="absolute inset-0">
        <img
          src={banner}
          alt={title}
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-black via-black/50 to-transparent" />
        <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent" />
      </div>

      <div className="relative container h-full flex items-center">
        <div className="max-w-2xl space-y-4">
          <h1 className="text-4xl md:text-6xl font-bold text-white text-shadow">
            {title}
          </h1>
          
          <div className="flex items-center gap-4 text-sm text-white/90">
            {year && <span>{year}</span>}
            {rating && (
              <>
                <span>•</span>
                <span className="border border-white/50 px-2 py-0.5 rounded">
                  {rating}
                </span>
              </>
            )}
            {tags && (
              <>
                <span>•</span>
                <span>{tags}</span>
              </>
            )}
          </div>

          <p className="text-base md:text-lg text-white/90 line-clamp-3 text-shadow">
            {description}
          </p>

          <div className="flex gap-3 pt-2">
            {episodeId ? (
              <Button asChild size="lg" className="gap-2">
                <Link href={`/watch/${episodeId}`}>
                  <Play className="h-5 w-5" />
                  Assistir
                </Link>
              </Button>
            ) : (
              <Button asChild size="lg" variant="secondary" className="gap-2">
                <Link href={`/anime/${animeId}`}>
                  <Info className="h-5 w-5" />
                  Mais Informações
                </Link>
              </Button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
