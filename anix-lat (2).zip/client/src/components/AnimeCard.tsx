import { Link } from "wouter";
import { Play } from "lucide-react";

interface AnimeCardProps {
  animeId: number;
  thumbnail: string;
  title?: string;
  episodeNumber?: number;
  dubbed?: boolean;
  size?: "small" | "medium" | "large";
}

export default function AnimeCard({
  animeId,
  thumbnail,
  title,
  episodeNumber,
  dubbed,
  size = "medium",
}: AnimeCardProps) {
  const sizeClasses = {
    small: "w-28 h-40 md:w-32 md:h-48",
    medium: "w-32 h-48 md:w-40 md:h-60 lg:w-44 lg:h-64",
    large: "w-40 h-60 md:w-48 md:h-72",
  };

  return (
    <Link href={`/anime/${animeId}`}>
      <div className="group block">
        <div
          className={`${sizeClasses[size]} relative rounded-md overflow-hidden bg-card hover-scale cursor-pointer`}
        >
          <img
            src={thumbnail}
            alt={title || `Anime ${animeId}`}
            className="w-full h-full object-cover"
            loading="lazy"
          />
          <div className="absolute inset-0 bg-black/0 group-hover:bg-black/60 transition-all duration-300 flex items-center justify-center">
            <Play className="h-12 w-12 text-white opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
          </div>
          {dubbed && (
            <div className="absolute top-2 right-2 bg-primary text-primary-foreground text-xs px-2 py-1 rounded">
              DUB
            </div>
          )}
          {episodeNumber && (
            <div className="absolute bottom-0 left-0 right-0 gradient-overlay p-2">
              <p className="text-xs text-white text-shadow">EP {episodeNumber}</p>
            </div>
          )}
        </div>
        {title && (
          <p className="mt-2 text-sm text-foreground/80 line-clamp-2">{title}</p>
        )}
      </div>
    </Link>
  );
}
