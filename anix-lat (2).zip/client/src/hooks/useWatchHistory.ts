import { useState, useEffect } from "react";

export interface WatchHistoryItem {
  animeId: number;
  animeName: string;
  animeImage: string;
  episodeId: number;
  episodeNumber: number;
  currentTime: number;
  duration: number;
  timestamp: number;
  completed: boolean;
}

const STORAGE_KEY = "anix_watch_history";

export function useWatchHistory() {
  const [history, setHistory] = useState<WatchHistoryItem[]>([]);

  // Load history from localStorage on mount
  useEffect(() => {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (stored) {
      try {
        setHistory(JSON.parse(stored));
      } catch (e) {
        console.error("Failed to parse watch history:", e);
        setHistory([]);
      }
    }
  }, []);

  // Save progress for an episode
  const saveProgress = (item: WatchHistoryItem) => {
    setHistory((prev) => {
      // Remove existing entry for this episode
      const filtered = prev.filter((h) => h.episodeId !== item.episodeId);
      
      // Add new entry at the beginning
      const updated = [item, ...filtered];
      
      // Keep only last 100 items
      const trimmed = updated.slice(0, 100);
      
      // Save to localStorage
      localStorage.setItem(STORAGE_KEY, JSON.stringify(trimmed));
      
      return trimmed;
    });
  };

  // Get progress for specific episode
  const getProgress = (episodeId: number): WatchHistoryItem | undefined => {
    return history.find((h) => h.episodeId === episodeId);
  };

  // Get recent watch history (last 6 for "Continue Watching")
  const getRecent = (limit: number = 6): WatchHistoryItem[] => {
    return history
      .filter((h) => !h.completed) // Only show incomplete episodes
      .slice(0, limit);
  };

  // Get all history grouped by anime
  const getGroupedHistory = (): Map<number, WatchHistoryItem[]> => {
    const grouped = new Map<number, WatchHistoryItem[]>();
    
    history.forEach((item) => {
      const existing = grouped.get(item.animeId) || [];
      grouped.set(item.animeId, [...existing, item]);
    });
    
    return grouped;
  };

  // Clear entire history
  const clearHistory = () => {
    localStorage.removeItem(STORAGE_KEY);
    setHistory([]);
  };

  // Remove specific anime from history
  const removeAnime = (animeId: number) => {
    setHistory((prev) => {
      const filtered = prev.filter((h) => h.animeId !== animeId);
      localStorage.setItem(STORAGE_KEY, JSON.stringify(filtered));
      return filtered;
    });
  };

  return {
    history,
    saveProgress,
    getProgress,
    getRecent,
    getGroupedHistory,
    clearHistory,
    removeAnime,
  };
}
