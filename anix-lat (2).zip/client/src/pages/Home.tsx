import { trpc } from "@/lib/trpc";
import Navbar from "@/components/Navbar";
import HeroBanner from "@/components/HeroBanner";
import AnimeCarousel from "@/components/AnimeCarousel";
import Footer from "@/components/Footer";
import { Loader2, Play, Clock } from "lucide-react";
import { useWatchHistory } from "@/hooks/useWatchHistory";
import { Link } from "wouter";
import { useState, useEffect } from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { AlertTriangle, Info, CheckCircle, XCircle } from "lucide-react";

export default function Home() {
  const { data: feedData, isLoading, error } = trpc.anime.getFeed.useQuery();
  const { data: announcements } = trpc.public.getActiveAnnouncements.useQuery();
  const { getRecent } = useWatchHistory();
  const recentHistory = getRecent(6);
  
  const [showAnnouncement, setShowAnnouncement] = useState(false);
  const [currentAnnouncementIndex, setCurrentAnnouncementIndex] = useState(0);

  useEffect(() => {
    if (announcements && announcements.length > 0) {
      setShowAnnouncement(true);
    }
  }, [announcements]);

  const handleNextAnnouncement = () => {
    if (announcements && currentAnnouncementIndex < announcements.length - 1) {
      setCurrentAnnouncementIndex(currentAnnouncementIndex + 1);
    } else {
      setShowAnnouncement(false);
      setCurrentAnnouncementIndex(0);
    }
  };

  const getAnnouncementIcon = (type: string) => {
    switch (type) {
      case "success":
        return <CheckCircle className="h-6 w-6 text-green-500" />;
      case "warning":
        return <AlertTriangle className="h-6 w-6 text-yellow-500" />;
      case "error":
        return <XCircle className="h-6 w-6 text-red-500" />;
      default:
        return <Info className="h-6 w-6 text-blue-500" />;
    }
  };

  const currentAnnouncement = announcements?.[currentAnnouncementIndex];

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Loader2 className="h-12 w-12 animate-spin text-primary" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <p className="text-xl text-foreground/80">Erro ao carregar animes</p>
          <p className="text-sm text-muted-foreground mt-2">{error.message}</p>
        </div>
      </div>
    );
  }

  const heroBanner = feedData?.data?.find((item) => item.type === 6);
  const sections = feedData?.data?.filter((item) => [3, 5, 7].includes(item.type || 0));

  return (
    <div className="min-h-screen bg-background">
      <Navbar />

      {/* Announcement Dialog */}
      {currentAnnouncement && (
        <Dialog open={showAnnouncement} onOpenChange={setShowAnnouncement}>
          <DialogContent className="bg-zinc-900 border-zinc-800 text-white">
            <DialogHeader>
              <div className="flex items-center gap-3 mb-2">
                {getAnnouncementIcon(currentAnnouncement.type)}
                <DialogTitle className="text-xl">{currentAnnouncement.title}</DialogTitle>
              </div>
              <DialogDescription className="text-zinc-300 text-base">
                {currentAnnouncement.message}
              </DialogDescription>
            </DialogHeader>
            <div className="flex justify-end gap-2 mt-4">
              {announcements && announcements.length > 1 && (
                <p className="text-sm text-zinc-500 mr-auto">
                  {currentAnnouncementIndex + 1} de {announcements.length}
                </p>
              )}
              <Button
                onClick={handleNextAnnouncement}
                className="bg-red-600 hover:bg-red-700"
              >
                {announcements && currentAnnouncementIndex < announcements.length - 1
                  ? "Próximo"
                  : "Entendi"}
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      )}

      {heroBanner && (
        <HeroBanner
          animeId={heroBanner.anime_id || 0}
          title={heroBanner.title || ""}
          description={heroBanner.text || ""}
          banner={heroBanner.banner || ""}
          tags={heroBanner.tags}
          year={heroBanner.year}
          rating={heroBanner.rating}
          episodeId={heroBanner.episode_id}
        />
      )}

      <div className="px-4 md:px-8 lg:px-12 py-8 md:py-12 space-y-8 md:space-y-12">
        {/* Continue Watching Section */}
        {recentHistory.length > 0 && (
          <div>
            <h2 className="text-2xl font-bold mb-6 flex items-center gap-2">
              <Clock className="h-6 w-6" />
              Continuar Assistindo
            </h2>
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
              {recentHistory.map((item) => (
                <Link key={item.episodeId} href={`/watch/${item.episodeId}`}>
                  <div className="group cursor-pointer">
                    <div className="relative aspect-[2/3] rounded-lg overflow-hidden bg-muted">
                      <img
                        src={item.animeImage}
                        alt={item.animeName}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />
                      <div className="absolute bottom-0 left-0 right-0 p-3">
                        <div className="flex items-center gap-2 mb-2">
                          <Play className="h-4 w-4 text-primary" />
                          <span className="text-xs font-medium">EP {item.episodeNumber}</span>
                        </div>
                        <div className="w-full bg-white/20 rounded-full h-1">
                          <div
                            className="bg-primary h-1 rounded-full"
                            style={{ width: `${(item.currentTime / item.duration) * 100}%` }}
                          />
                        </div>
                      </div>
                    </div>
                    <p className="mt-2 text-sm font-medium line-clamp-2">{item.animeName}</p>
                  </div>
                </Link>
              ))}
            </div>
          </div>
        )}

        {sections?.map((section, index) => {
          if (!section.title || !section.data) return null;
          
          return (
            <AnimeCarousel
              key={`${section.type}-${index}`}
              title={section.title}
              items={section.data}
            />
          );
        })}
      </div>

      <Footer />
    </div>
  );
}
