import Navbar from "@/components/Navbar";
import { Heart, Clock, Trash2 } from "lucide-react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { useState, useEffect } from "react";

interface FavoriteItem {
  animeId: number;
  animeName: string;
  animeCape: string;
  addedAt: string;
}

interface HistoryItem {
  animeId: number;
  episodeId: number;
  episodeNumber: number;
  watchProgress: number;
  totalDuration: number;
  completed: boolean;
  lastWatchedAt: string;
  animeName: string;
  animeBanner: string;
}

export default function Profile() {
  const [favorites, setFavorites] = useState<FavoriteItem[]>([]);
  const [history, setHistory] = useState<HistoryItem[]>([]);

  useEffect(() => {
    // Load data from localStorage
    const favoritesData = JSON.parse(localStorage.getItem("favorites") || "[]");
    const historyData = JSON.parse(localStorage.getItem("watch_history") || "[]");
    
    setFavorites(favoritesData);
    setHistory(historyData.slice(0, 6)); // Show only last 6
  }, []);

  const clearAllData = () => {
    if (confirm("Tem certeza que deseja limpar todos os seus dados (favoritos e histórico)?")) {
      localStorage.removeItem("favorites");
      localStorage.removeItem("watch_history");
      setFavorites([]);
      setHistory([]);
    }
  };

  const totalWatchTime = history.reduce((acc, item) => acc + item.watchProgress, 0);
  const totalWatchMinutes = Math.floor(totalWatchTime / 60);
  const totalWatchHours = Math.floor(totalWatchMinutes / 60);

  return (
    <div className="min-h-screen bg-background">
      <Navbar />

      <div className="container py-8 md:py-12">
        {/* Header */}
        <div className="mb-8 md:mb-12">
          <h1 className="text-3xl md:text-4xl font-bold mb-2">Meu Perfil</h1>
          <p className="text-foreground/70">Seus dados locais salvos no navegador</p>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 md:gap-6 mb-8 md:mb-12">
          <div className="bg-card border border-border rounded-lg p-6">
            <div className="flex items-center gap-4">
              <div className="p-3 bg-primary/20 rounded-lg">
                <Heart className="h-6 w-6 text-primary" />
              </div>
              <div>
                <p className="text-2xl font-bold">{favorites.length}</p>
                <p className="text-sm text-muted-foreground">Favoritos</p>
              </div>
            </div>
          </div>

          <div className="bg-card border border-border rounded-lg p-6">
            <div className="flex items-center gap-4">
              <div className="p-3 bg-primary/20 rounded-lg">
                <Clock className="h-6 w-6 text-primary" />
              </div>
              <div>
                <p className="text-2xl font-bold">{history.length}</p>
                <p className="text-sm text-muted-foreground">Episódios Assistidos</p>
              </div>
            </div>
          </div>

          <div className="bg-card border border-border rounded-lg p-6">
            <div className="flex items-center gap-4">
              <div className="p-3 bg-primary/20 rounded-lg">
                <Clock className="h-6 w-6 text-primary" />
              </div>
              <div>
                <p className="text-2xl font-bold">{totalWatchHours}h</p>
                <p className="text-sm text-muted-foreground">Tempo Assistido</p>
              </div>
            </div>
          </div>
        </div>

        {/* Favorites Section */}
        <div className="mb-8 md:mb-12">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-2xl font-bold">Meus Favoritos</h2>
          </div>

          {favorites.length === 0 ? (
            <div className="text-center py-12 bg-card rounded-lg border border-border">
              <Heart className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
              <p className="text-foreground/80">Você ainda não tem favoritos</p>
              <p className="text-sm text-muted-foreground mt-2">
                Adicione animes aos favoritos para vê-los aqui
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
              {favorites.slice(0, 12).map((fav) => (
                <Link key={fav.animeId} href={`/anime/${fav.animeId}`}>
                  <div className="group cursor-pointer">
                    <div className="relative aspect-[2/3] overflow-hidden rounded-lg mb-2 bg-muted">
                      {fav.animeCape ? (
                        <img
                          src={fav.animeCape}
                          alt={fav.animeName}
                          className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                        />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center">
                          <Heart className="h-8 w-8 text-muted-foreground" />
                        </div>
                      )}
                    </div>
                    <h3 className="text-sm font-medium line-clamp-2">{fav.animeName}</h3>
                  </div>
                </Link>
              ))}
            </div>
          )}
        </div>

        {/* Recent History */}
        <div className="mb-8 md:mb-12">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-2xl font-bold">Continuar Assistindo</h2>
            <Link href="/history">
              <Button variant="outline">Ver Histórico</Button>
            </Link>
          </div>

          {history.length === 0 ? (
            <div className="text-center py-12 bg-card rounded-lg border border-border">
              <Clock className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
              <p className="text-foreground/80">Você ainda não assistiu nenhum episódio</p>
              <p className="text-sm text-muted-foreground mt-2">
                Comece a assistir para ver seu histórico aqui
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {history.map((item) => {
                const progressPercent = (item.watchProgress / item.totalDuration) * 100;

                return (
                  <Link key={item.episodeId} href={`/watch/${item.episodeId}`}>
                    <div className="group bg-card rounded-lg overflow-hidden border border-border hover:border-primary transition-all">
                      <div className="relative aspect-video bg-muted">
                        {item.animeBanner ? (
                          <img
                            src={item.animeBanner}
                            alt={item.animeName}
                            className="w-full h-full object-cover"
                          />
                        ) : (
                          <div className="w-full h-full flex items-center justify-center">
                            <Clock className="h-8 w-8 text-muted-foreground" />
                          </div>
                        )}
                        <div className="absolute bottom-0 left-0 right-0 h-1 bg-black/50">
                          <div
                            className="h-full bg-primary"
                            style={{ width: `${progressPercent}%` }}
                          />
                        </div>
                      </div>
                      <div className="p-3">
                        <h3 className="font-semibold line-clamp-1 text-sm">
                          {item.animeName}
                        </h3>
                        <p className="text-xs text-muted-foreground">
                          Episódio {item.episodeNumber}
                        </p>
                      </div>
                    </div>
                  </Link>
                );
              })}
            </div>
          )}
        </div>

        {/* Data Management */}
        <div className="bg-card border border-border rounded-lg p-6">
          <h2 className="text-xl font-bold mb-4">Gerenciar Dados</h2>
          <p className="text-sm text-muted-foreground mb-4">
            Todos os seus dados (favoritos e histórico) são salvos localmente no seu navegador.
            Eles não são sincronizados entre dispositivos.
          </p>
          <Button
            variant="destructive"
            onClick={clearAllData}
            className="gap-2"
          >
            <Trash2 className="h-4 w-4" />
            Limpar Todos os Dados
          </Button>
        </div>
      </div>
    </div>
  );
}
