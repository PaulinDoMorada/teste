import { useRoute, Link } from "wouter";
import { trpc } from "@/lib/trpc";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { Play, Heart, Loader2, ChevronDown, ChevronUp } from "lucide-react";
import { toast } from "sonner";
import { useState, useEffect } from "react";

export default function AnimeDetails() {
  const [, params] = useRoute("/anime/:id");
  const animeId = parseInt(params?.id || "0");
  const [expandedSeasons, setExpandedSeasons] = useState<Record<number, boolean>>({});
  const [isFavorite, setIsFavorite] = useState(false);

  const { data: animeData, isLoading } = trpc.anime.getDetails.useQuery(
    { animeId },
    { enabled: animeId > 0 }
  );

  // Check if anime is in favorites (localStorage)
  useEffect(() => {
    const favoritesKey = `favorites`;
    const favorites = JSON.parse(localStorage.getItem(favoritesKey) || "[]");
    setIsFavorite(favorites.some((fav: any) => fav.animeId === animeId));
  }, [animeId]);

  const toggleFavorite = () => {
    const favoritesKey = `favorites`;
    const favorites = JSON.parse(localStorage.getItem(favoritesKey) || "[]");
    
    if (isFavorite) {
      // Remove from favorites
      const newFavorites = favorites.filter((fav: any) => fav.animeId !== animeId);
      localStorage.setItem(favoritesKey, JSON.stringify(newFavorites));
      setIsFavorite(false);
      toast.success("Removido dos favoritos!");
    } else {
      // Add to favorites
      const newFavorite = {
        animeId,
        animeName: animeData?.anime_details?.anime_name || "",
        animeCape: animeData?.anime_details?.anime_cape_url || "",
        addedAt: new Date().toISOString(),
      };
      favorites.unshift(newFavorite);
      localStorage.setItem(favoritesKey, JSON.stringify(favorites));
      setIsFavorite(true);
      toast.success("Adicionado aos favoritos!");
    }
  };

  const toggleSeason = (seasonId: number) => {
    setExpandedSeasons(prev => ({
      ...prev,
      [seasonId]: !prev[seasonId]
    }));
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!animeData?.anime_details) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <div className="container py-20 text-center">
          <p className="text-xl text-foreground/80">Anime não encontrado</p>
        </div>
      </div>
    );
  }

  const anime = animeData.anime_details;

  return (
    <div className="min-h-screen bg-background">
      <Navbar />

      {/* Hero Banner */}
      <div className="relative h-[50vh] md:h-[60vh] w-full overflow-hidden">
        <div className="absolute inset-0">
          <img
            src={anime.anime_banner_url}
            alt={anime.anime_name}
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-black via-black/70 to-transparent" />
          <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent" />
        </div>

        <div className="relative container h-full flex items-end pb-8 md:pb-12">
          <div className="flex flex-col md:flex-row gap-4 md:gap-6 items-start md:items-end w-full">
            <img
              src={anime.anime_cape_url}
              alt={anime.anime_name}
              className="w-32 h-48 md:w-48 md:h-72 object-cover rounded-lg shadow-2xl"
            />
            <div className="space-y-3 md:space-y-4 pb-0 md:pb-4 flex-1">
              <h1 className="text-3xl md:text-4xl lg:text-5xl font-bold text-white text-shadow">
                {anime.anime_name}
              </h1>
              <div className="flex flex-wrap items-center gap-2 md:gap-4 text-xs md:text-sm text-white/90">
                <span>{anime.anime_date}</span>
                <span>•</span>
                <span className="border border-white/50 px-2 py-0.5 rounded">
                  {anime.anime_parental_rating}
                </span>
                <span>•</span>
                <span>{anime.anime_genre}</span>
                {anime.dub_available && (
                  <>
                    <span>•</span>
                    <span className="bg-primary/20 border border-primary px-2 py-0.5 rounded">
                      Dublado
                    </span>
                  </>
                )}
              </div>
              <div className="flex flex-wrap gap-2 md:gap-3">
                <Button
                  onClick={toggleFavorite}
                  variant="outline"
                  size="lg"
                  className="gap-2 bg-white/10 backdrop-blur border-white/20 hover:bg-white/20 text-white"
                >
                  <Heart className={isFavorite ? "fill-primary text-primary" : ""} />
                  {isFavorite ? "Favoritado" : "Favoritar"}
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="container py-8 md:py-12">
        <div className="max-w-4xl">
          <h2 className="text-xl md:text-2xl font-bold mb-3 md:mb-4">Sinopse</h2>
          <p className="text-sm md:text-base text-foreground/80 leading-relaxed mb-8 md:mb-12">
            {anime.anime_description}
          </p>

          <h2 className="text-xl md:text-2xl font-bold mb-4 md:mb-6">Temporadas e Episódios</h2>
          <div className="space-y-3 md:space-y-4">
            {animeData.anime_seasons?.map((season: any) => (
              <SeasonCard
                key={season.season_id}
                season={season}
                isExpanded={expandedSeasons[season.season_id]}
                onToggle={() => toggleSeason(season.season_id)}
              />
            ))}
          </div>
        </div>
      </div>
      <Footer />
    </div>
  );
}

function SeasonCard({ season, isExpanded, onToggle }: {
  season: any;
  isExpanded: boolean;
  onToggle: () => void;
}) {
  const { data: episodesData, isLoading } = trpc.anime.getSeasonEpisodes.useQuery(
    { seasonId: season.season_id },
    { 
      enabled: isExpanded,
      refetchOnMount: true,
      refetchOnWindowFocus: false
    }
  );

  return (
    <div className="bg-card rounded-lg overflow-hidden border border-border">
      <button
        onClick={onToggle}
        className="w-full px-4 md:px-6 py-3 md:py-4 flex items-center justify-between hover:bg-accent/50 transition"
      >
        <div className="flex items-center gap-3 md:gap-4">
          <h3 className="text-base md:text-lg font-semibold text-left">{season.season_name}</h3>
          {season.season_dubbed === 1 && (
            <span className="text-xs bg-primary/20 text-primary px-2 py-1 rounded">
              Dublado
            </span>
          )}
        </div>
        {isExpanded ? (
          <ChevronUp className="w-5 h-5 flex-shrink-0" />
        ) : (
          <ChevronDown className="w-5 h-5 flex-shrink-0" />
        )}
      </button>

      {isExpanded && (
        <div className="border-t border-border">
          {isLoading ? (
            <div className="p-8 flex items-center justify-center">
              <Loader2 className="w-6 h-6 animate-spin text-primary" />
            </div>
          ) : episodesData?.data && episodesData.data.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3 md:gap-4 p-4 md:p-6">
              {episodesData.data.map((episode: any) => (
                <Link key={episode.ep_id} href={`/watch/${episode.ep_id}`}>
                  <div className="group block bg-background rounded-lg overflow-hidden hover:ring-2 hover:ring-primary transition">
                    <div className="relative aspect-video">
                      <img
                        src={episode.ep_thumbnail}
                        alt={episode.ep_name}
                        className="w-full h-full object-cover"
                      />
                      <div className="absolute inset-0 bg-black/0 group-hover:bg-black/60 transition flex items-center justify-center">
                        <Play className="w-12 h-12 text-white opacity-0 group-hover:opacity-100 transition" />
                      </div>
                    </div>
                    <div className="p-3">
                      <p className="text-xs md:text-sm font-semibold text-foreground/60 mb-1">
                        Episódio {episode.ep_number}
                      </p>
                      <h4 className="text-sm md:text-base font-medium line-clamp-2">
                        {episode.ep_name}
                      </h4>
                      <p className="text-xs text-foreground/60 mt-1">
                        {episode.ep_lenght_minutes} min
                      </p>
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          ) : (
            <div className="p-8 text-center text-foreground/60">
              Nenhum episódio disponível
            </div>
          )}
        </div>
      )}
    </div>
  );
}
