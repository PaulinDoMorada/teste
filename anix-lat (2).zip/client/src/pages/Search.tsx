import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import Navbar from "@/components/Navbar";
import AnimeCard from "@/components/AnimeCard";
import Footer from "@/components/Footer";
import { Loader2, Search as SearchIcon } from "lucide-react";
import { useEffect, useState } from "react";

export default function Search() {
  const [location] = useLocation();
  const [query, setQuery] = useState("");
  const [debouncedQuery, setDebouncedQuery] = useState("");

  useEffect(() => {
    const searchParams = new URLSearchParams(window.location.search);
    const q = searchParams.get("q") || "";
    setQuery(q);
  }, [location]);

  useEffect(() => {
    const timer = setTimeout(() => {
      setDebouncedQuery(query);
    }, 300); // Reduced to 300ms for faster response

    return () => clearTimeout(timer);
  }, [query]);

  const { data: searchResults, isLoading } = trpc.anime.search.useQuery(
    { query: debouncedQuery },
    { enabled: debouncedQuery.length > 0 }
  );

  return (
    <div className="min-h-screen bg-background">
      <Navbar />

      <div className="container py-24">
        <h1 className="text-3xl font-bold mb-8">
          Resultados para: <span className="text-primary">{query}</span>
        </h1>

        {isLoading ? (
          <div className="flex items-center justify-center h-64">
            <Loader2 className="h-12 w-12 animate-spin text-primary" />
          </div>
        ) : searchResults?.result && searchResults.result.length > 0 ? (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4">
            {searchResults.result.map((anime: any) => (
              <AnimeCard
                key={anime.id}
                animeId={anime.id}
                thumbnail={anime.image}
                title={anime.name}
              />
            ))}
          </div>
        ) : debouncedQuery.length > 0 ? (
          <div className="text-center py-20">
            <SearchIcon className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
            <p className="text-xl text-foreground/80">
              Nenhum resultado encontrado para "{query}"
            </p>
            <p className="text-sm text-muted-foreground mt-2">
              Tente usar palavras-chave diferentes ou verifique a ortografia
            </p>
          </div>
        ) : null}
      </div>
      <Footer />
    </div>
  );
}
