import { useRoute, useLocation, Link } from "wouter";
import { trpc } from "@/lib/trpc";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import VideoPlayer from "@/components/VideoPlayer";
import { Button } from "@/components/ui/button";
import { ArrowLeft, Loader2, Play, ChevronRight } from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { useWatchHistory } from "@/hooks/useWatchHistory";

// Fixed React key warning
export default function Watch() {
  const [, params] = useRoute("/watch/:episodeId");
  const [, setLocation] = useLocation();
  const episodeId = parseInt(params?.episodeId || "0");
  const progressSaveInterval = useRef<NodeJS.Timeout | undefined>(undefined);
  const [initialTime, setInitialTime] = useState(0);
  const [showNextEpisode, setShowNextEpisode] = useState(false);
  const { saveProgress, getProgress } = useWatchHistory();

  const { data: streamData, isLoading } = trpc.anime.getEpisodeStream.useQuery(
    { episodeId },
    { enabled: episodeId > 0 }
  );

  const { data: animeData } = trpc.anime.getDetails.useQuery(
    { animeId: streamData?.episodeAnimeID || 0 },
    { enabled: !!streamData?.episodeAnimeID }
  );

  const { data: feedData } = trpc.anime.getFeed.useQuery();

  // Load progress from localStorage using hook
  useEffect(() => {
    const progress = getProgress(episodeId);
    if (progress) {
      setInitialTime(progress.currentTime);
    }
  }, [episodeId, getProgress]);

  // Reset showNextEpisode when episodeId changes
  useEffect(() => {
    setShowNextEpisode(false);
  }, [episodeId]);

  useEffect(() => {
    return () => {
      if (progressSaveInterval.current) {
        clearInterval(progressSaveInterval.current);
      }
    };
  }, []);

  const handleVideoProgress = (currentTime: number, duration: number) => {
    // No longer needed - buttons are now permanent
  };

  const handleTimeUpdate = (currentTime: number, duration: number) => {
    if (!streamData) return;

    if (progressSaveInterval.current) {
      clearInterval(progressSaveInterval.current);
    }

    progressSaveInterval.current = setInterval(() => {
      const completed = currentTime / duration > 0.9;
      
      // Save using hook
      saveProgress({
        animeId: streamData.episodeAnimeID,
        animeName: animeData?.anime_details?.anime_name || "",
        animeImage: animeData?.anime_details?.anime_banner_url || "",
        episodeId: episodeId,
        episodeNumber: streamData.episodeNumber,
        currentTime: Math.floor(currentTime),
        duration: Math.floor(duration),
        timestamp: Date.now(),
        completed,
      });
    }, 5000); // Save every 5 seconds for real-time updates
  };

  const handleNextEpisode = () => {
    if (streamData?.nextEpisodeID) {
      setLocation(`/watch/${streamData.nextEpisodeID}`);
    }
  };



  if (isLoading) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <div className="flex items-center justify-center h-[80vh]">
          <Loader2 className="h-12 w-12 animate-spin text-primary" />
        </div>
      </div>
    );
  }

  if (!streamData?.streams) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <div className="container py-20 text-center">
          <p className="text-xl text-foreground/80">Episódio não encontrado</p>
        </div>
      </div>
    );
  }

  const streamUrl = streamData.streams.fhd || streamData.streams.mhd || streamData.streams.shd;

  // Get recommendations from feed - always show popular animes
  const recommendations = feedData?.data
    ?.flatMap((section: any) => section.data || [])
    ?.filter((anime: any) => anime && anime.id && anime.name)
    ?.slice(0, 12) || [];

  return (
    <div className="min-h-screen bg-background">
      <Navbar />

      <div className="pt-16">
        {/* Player Section */}
        <div className="bg-black">
          <div className="container max-w-7xl">
            <div className="py-4 md:py-6">
              <Link href={`/anime/${streamData.episodeAnimeID}`}>
                <Button variant="ghost" className="gap-2 text-white hover:text-white/80 mb-3 md:mb-4">
                  <ArrowLeft className="h-4 w-4" />
                  Voltar para o anime
                </Button>
              </Link>
            </div>

            <div className="aspect-video w-full relative">
              {streamUrl && (
                <VideoPlayer
                  streamUrl={streamUrl}
                  qualities={streamData.streams}
                  initialTime={initialTime}
                  onTimeUpdate={(time, duration) => {
                    handleTimeUpdate(time, duration);
                    handleVideoProgress(time, duration);
                  }}
                  onNextEpisode={handleNextEpisode}
                  hasNextEpisode={streamData.episodeHasNext}
                />
              )}


            </div>

            {/* Navigation Buttons */}
            <div className="py-4 md:py-6">
              {streamData.episodeHasNext && (
                <Button
                  onClick={handleNextEpisode}
                  className="gap-2 w-full"
                  size="lg"
                >
                  Próximo Episódio
                  <ChevronRight className="h-4 w-4" />
                </Button>
              )}
            </div>

            {/* Episode Info */}
            <div className="py-4 md:py-6 space-y-3 md:space-y-4 border-t border-white/10">
              <div>
                <h1 className="text-xl md:text-2xl lg:text-3xl font-bold text-white mb-2">
                  {streamData.episodeName}
                </h1>
                <p className="text-sm md:text-base text-white/70">
                  Episódio {streamData.episodeNumber}
                </p>
              </div>
            </div>

            {/* Anime Information */}
            {animeData?.anime_details && (
              <div className="py-4 md:py-6 space-y-4 border-t border-white/10">
                <h2 className="text-lg md:text-xl font-bold text-white">Sobre o Anime</h2>
                
                <div className="space-y-3">
                  <div>
                    <h3 className="text-base md:text-lg font-semibold text-white mb-2">
                      {animeData.anime_details.anime_name}
                    </h3>
                    <p className="text-sm md:text-base text-white/70 leading-relaxed">
                      {animeData.anime_details.anime_description}
                    </p>
                  </div>

                  <div className="flex flex-wrap gap-2">
                    {animeData.anime_details.anime_genre?.split(',').map((genre: string, index: number) => (
                      <span
                        key={index}
                        className="px-3 py-1 bg-primary/20 text-primary text-xs md:text-sm rounded-full"
                      >
                        {genre.trim()}
                      </span>
                    ))}
                  </div>

                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                    {animeData.anime_details.anime_date && (
                      <div>
                        <p className="text-white/60">Lançamento</p>
                        <p className="text-white font-medium">{animeData.anime_details.anime_date}</p>
                      </div>
                    )}
                    {animeData.anime_details.anime_parental_rating && (
                      <div>
                        <p className="text-white/60">Classificação</p>
                        <p className="text-white font-medium">{animeData.anime_details.anime_parental_rating}</p>
                      </div>
                    )}
                    {animeData.anime_details.release_day && (
                      <div>
                        <p className="text-white/60">Dia de Lançamento</p>
                        <p className="text-white font-medium">{animeData.anime_details.release_day}</p>
                      </div>
                    )}
                    {animeData.anime_details.anime_episodes && (
                      <div>
                        <p className="text-white/60">Episódios</p>
                        <p className="text-white font-medium">{animeData.anime_details.anime_episodes}</p>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Recommendations */}
        {recommendations.length > 0 && (
          <div className="container py-8 md:py-12">
            <h2 className="text-xl md:text-2xl font-bold mb-6">Você também pode gostar</h2>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
              {recommendations.map((anime: any) => (
                <Link key={anime.id} href={`/anime/${anime.id}`}>
                  <div className="group cursor-pointer">
                    <div className="relative aspect-[2/3] overflow-hidden rounded-lg mb-2">
                      <img
                        src={anime.image}
                        alt={anime.name}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                      />
                    </div>
                    <h3 className="text-sm font-medium line-clamp-2">{anime.name}</h3>
                  </div>
                </Link>
              ))}
            </div>
          </div>
        )}
      </div>
      <Footer />
    </div>
  );
}
