import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { trpc } from "../lib/trpc";
import { Button } from "../components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../components/ui/card";
import { Input } from "../components/ui/input";
import { Label } from "../components/ui/label";
import { Textarea } from "../components/ui/textarea";
import { Switch } from "../components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../components/ui/tabs";
import { Badge } from "../components/ui/badge";
import { toast } from "sonner";
import {
  Bell,
  Settings,
  AlertTriangle,
  Activity,
  Ban,
  LogOut,
  Send,
  Trash2,
  Shield,
  Eye,
} from "lucide-react";

export default function AdminDashboard() {
  const [, setLocation] = useLocation();
  const utils = trpc.useUtils();

  // Verificar sessão
  const { data: sessionData, isLoading: sessionLoading } = trpc.admin.verifySession.useQuery();

  useEffect(() => {
    if (!sessionLoading && !sessionData?.isValid) {
      setLocation("/admin/login");
    }
  }, [sessionData, sessionLoading, setLocation]);

  // Logout
  const logoutMutation = trpc.admin.logout.useMutation({
    onSuccess: () => {
      setLocation("/admin/login");
    },
  });

  // Notificações
  const [notifTitle, setNotifTitle] = useState("");
  const [notifMessage, setNotifMessage] = useState("");
  const [notifType, setNotifType] = useState<"info" | "warning" | "error" | "success">("info");

  const { data: notifications } = trpc.admin.getNotifications.useQuery(undefined, {
    enabled: sessionData?.isValid === true,
  });
  const sendNotificationMutation = trpc.admin.sendNotification.useMutation({
    onSuccess: () => {
      toast.success("Notificação enviada com sucesso!");
      setNotifTitle("");
      setNotifMessage("");
      utils.admin.getNotifications.invalidate();
    },
  });

  const deleteNotificationMutation = trpc.admin.deleteNotification.useMutation({
    onSuccess: () => {
      toast.success("Notificação deletada");
      utils.admin.getNotifications.invalidate();
    },
  });

  // Modo manutenção
  const { data: maintenanceStatus } = trpc.admin.getMaintenanceStatus.useQuery(undefined, {
    enabled: sessionData?.isValid === true,
  });
  const [maintenanceEnabled, setMaintenanceEnabled] = useState(false);
  const [maintenanceMessage, setMaintenanceMessage] = useState("");

  useEffect(() => {
    if (maintenanceStatus) {
      setMaintenanceEnabled(maintenanceStatus.enabled);
      setMaintenanceMessage(maintenanceStatus.message);
    }
  }, [maintenanceStatus]);

  const setMaintenanceMutation = trpc.admin.setMaintenanceMode.useMutation({
    onSuccess: () => {
      toast.success("Modo manutenção atualizado!");
      utils.admin.getMaintenanceStatus.invalidate();
    },
  });

  // Avisos
  const [announcementTitle, setAnnouncementTitle] = useState("");
  const [announcementMessage, setAnnouncementMessage] = useState("");
  const [announcementType, setAnnouncementType] = useState<"info" | "warning" | "error" | "success">("info");

  const { data: announcements } = trpc.admin.getAnnouncements.useQuery(undefined, {
    enabled: sessionData?.isValid === true,
  });
  const createAnnouncementMutation = trpc.admin.createAnnouncement.useMutation({
    onSuccess: () => {
      toast.success("Aviso criado com sucesso!");
      setAnnouncementTitle("");
      setAnnouncementMessage("");
      utils.admin.getAnnouncements.invalidate();
    },
  });

  const deleteAnnouncementMutation = trpc.admin.deleteAnnouncement.useMutation({
    onSuccess: () => {
      toast.success("Aviso deletado");
      utils.admin.getAnnouncements.invalidate();
    },
  });

  const toggleAnnouncementMutation = trpc.admin.updateAnnouncement.useMutation({
    onSuccess: () => {
      utils.admin.getAnnouncements.invalidate();
    },
  });

  // Logs de acesso
  const { data: accessLogs } = trpc.admin.getAccessLogs.useQuery(
    { limit: 50 },
    { enabled: sessionData?.isValid === true }
  );
  const { data: accessStats } = trpc.admin.getAccessStats.useQuery(undefined, {
    enabled: sessionData?.isValid === true,
  });

  // IPs banidos
  const [banIpAddress, setBanIpAddress] = useState("");
  const [banReason, setBanReason] = useState("");

  const { data: bannedIps } = trpc.admin.getBannedIps.useQuery(undefined, {
    enabled: sessionData?.isValid === true,
  });
  const banIpMutation = trpc.admin.banIp.useMutation({
    onSuccess: () => {
      toast.success("IP banido com sucesso!");
      setBanIpAddress("");
      setBanReason("");
      utils.admin.getBannedIps.invalidate();
    },
  });

  const unbanIpMutation = trpc.admin.unbanIp.useMutation({
    onSuccess: () => {
      toast.success("IP desbanido");
      utils.admin.getBannedIps.invalidate();
    },
  });

  if (sessionLoading) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center">
        <p className="text-white">Verificando sessão...</p>
      </div>
    );
  }

  if (!sessionData?.isValid) {
    return null;
  }

  return (
    <div className="min-h-screen bg-black text-white">
      {/* Header */}
      <div className="border-b border-zinc-800 bg-zinc-900">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Shield className="w-8 h-8 text-red-600" />
            <div>
              <h1 className="text-xl font-bold">Painel Administrativo</h1>
              <p className="text-sm text-zinc-400">ANIX-LAT</p>
            </div>
          </div>
          <Button
            variant="outline"
            onClick={() => logoutMutation.mutate()}
            className="border-zinc-700"
          >
            <LogOut className="w-4 h-4 mr-2" />
            Sair
          </Button>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        <Tabs defaultValue="notifications" className="space-y-6">
          <TabsList className="bg-zinc-900 border border-zinc-800">
            <TabsTrigger value="notifications">
              <Bell className="w-4 h-4 mr-2" />
              Notificações
            </TabsTrigger>
            <TabsTrigger value="maintenance">
              <Settings className="w-4 h-4 mr-2" />
              Manutenção
            </TabsTrigger>
            <TabsTrigger value="announcements">
              <AlertTriangle className="w-4 h-4 mr-2" />
              Avisos
            </TabsTrigger>
            <TabsTrigger value="logs">
              <Activity className="w-4 h-4 mr-2" />
              Logs
            </TabsTrigger>
            <TabsTrigger value="bans">
              <Ban className="w-4 h-4 mr-2" />
              Banimentos
            </TabsTrigger>
          </TabsList>

          {/* Notificações */}
          <TabsContent value="notifications" className="space-y-6">
            <Card className="bg-zinc-900 border-zinc-800">
              <CardHeader>
                <CardTitle>Enviar Notificação para Todos</CardTitle>
                <CardDescription>
                  Notificações aparecem no ícone do sininho para todos os usuários
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label>Título</Label>
                  <Input
                    value={notifTitle}
                    onChange={(e) => setNotifTitle(e.target.value)}
                    className="bg-zinc-800 border-zinc-700"
                    placeholder="Ex: Nova temporada disponível!"
                  />
                </div>
                <div className="space-y-2">
                  <Label>Mensagem</Label>
                  <Textarea
                    value={notifMessage}
                    onChange={(e) => setNotifMessage(e.target.value)}
                    className="bg-zinc-800 border-zinc-700"
                    placeholder="Digite a mensagem da notificação..."
                    rows={3}
                  />
                </div>
                <div className="space-y-2">
                  <Label>Tipo</Label>
                  <select
                    value={notifType}
                    onChange={(e) => setNotifType(e.target.value as any)}
                    className="w-full p-2 bg-zinc-800 border border-zinc-700 rounded-md text-white"
                  >
                    <option value="info">Info</option>
                    <option value="success">Sucesso</option>
                    <option value="warning">Aviso</option>
                    <option value="error">Erro</option>
                  </select>
                </div>
                <Button
                  onClick={() =>
                    sendNotificationMutation.mutate({
                      title: notifTitle,
                      message: notifMessage,
                      type: notifType,
                    })
                  }
                  disabled={!notifTitle || !notifMessage || sendNotificationMutation.isPending}
                  className="bg-red-600 hover:bg-red-700"
                >
                  <Send className="w-4 h-4 mr-2" />
                  Enviar Notificação
                </Button>
              </CardContent>
            </Card>

            <Card className="bg-zinc-900 border-zinc-800">
              <CardHeader>
                <CardTitle>Notificações Enviadas</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {notifications?.map((notif) => (
                    <div
                      key={notif.id}
                      className="flex items-start justify-between p-3 bg-zinc-800 rounded-lg"
                    >
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <Badge variant={notif.type === "error" ? "destructive" : "default"}>
                            {notif.type}
                          </Badge>
                          <span className="font-medium">{notif.title}</span>
                        </div>
                        <p className="text-sm text-zinc-400">{notif.message}</p>
                        <p className="text-xs text-zinc-500 mt-1">
                          {new Date(notif.createdAt).toLocaleString("pt-BR")}
                        </p>
                      </div>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => deleteNotificationMutation.mutate({ id: notif.id })}
                      >
                        <Trash2 className="w-4 h-4 text-red-500" />
                      </Button>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Modo Manutenção */}
          <TabsContent value="maintenance" className="space-y-6">
            <Card className="bg-zinc-900 border-zinc-800">
              <CardHeader>
                <CardTitle>Modo Manutenção</CardTitle>
                <CardDescription>
                  Quando ativado, o site ficará inacessível para usuários comuns
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between p-4 bg-zinc-800 rounded-lg">
                  <div>
                    <p className="font-medium">Status do Site</p>
                    <p className="text-sm text-zinc-400">
                      {maintenanceEnabled ? "Em manutenção" : "Online"}
                    </p>
                  </div>
                  <Switch
                    checked={maintenanceEnabled}
                    onCheckedChange={(checked) => {
                      setMaintenanceEnabled(checked);
                      setMaintenanceMutation.mutate({
                        enabled: checked,
                        message: maintenanceMessage,
                      });
                    }}
                  />
                </div>
                <div className="space-y-2">
                  <Label>Mensagem de Manutenção</Label>
                  <Textarea
                    value={maintenanceMessage}
                    onChange={(e) => setMaintenanceMessage(e.target.value)}
                    className="bg-zinc-800 border-zinc-700"
                    rows={3}
                  />
                  <Button
                    onClick={() =>
                      setMaintenanceMutation.mutate({
                        enabled: maintenanceEnabled,
                        message: maintenanceMessage,
                      })
                    }
                    variant="outline"
                    className="border-zinc-700"
                  >
                    Atualizar Mensagem
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Avisos */}
          <TabsContent value="announcements" className="space-y-6">
            <Card className="bg-zinc-900 border-zinc-800">
              <CardHeader>
                <CardTitle>Criar Aviso</CardTitle>
                <CardDescription>
                  Avisos aparecem em dialog na página inicial
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label>Título</Label>
                  <Input
                    value={announcementTitle}
                    onChange={(e) => setAnnouncementTitle(e.target.value)}
                    className="bg-zinc-800 border-zinc-700"
                  />
                </div>
                <div className="space-y-2">
                  <Label>Mensagem</Label>
                  <Textarea
                    value={announcementMessage}
                    onChange={(e) => setAnnouncementMessage(e.target.value)}
                    className="bg-zinc-800 border-zinc-700"
                    rows={3}
                  />
                </div>
                <div className="space-y-2">
                  <Label>Tipo</Label>
                  <select
                    value={announcementType}
                    onChange={(e) => setAnnouncementType(e.target.value as any)}
                    className="w-full p-2 bg-zinc-800 border border-zinc-700 rounded-md text-white"
                  >
                    <option value="info">Info</option>
                    <option value="success">Sucesso</option>
                    <option value="warning">Aviso</option>
                    <option value="error">Erro</option>
                  </select>
                </div>
                <Button
                  onClick={() =>
                    createAnnouncementMutation.mutate({
                      title: announcementTitle,
                      message: announcementMessage,
                      type: announcementType,
                    })
                  }
                  disabled={!announcementTitle || !announcementMessage}
                  className="bg-red-600 hover:bg-red-700"
                >
                  Criar Aviso
                </Button>
              </CardContent>
            </Card>

            <Card className="bg-zinc-900 border-zinc-800">
              <CardHeader>
                <CardTitle>Avisos Ativos</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {announcements?.map((announcement) => (
                    <div
                      key={announcement.id}
                      className="flex items-start justify-between p-3 bg-zinc-800 rounded-lg"
                    >
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <Badge>{announcement.type}</Badge>
                          <span className="font-medium">{announcement.title}</span>
                          {announcement.isActive && (
                            <Badge variant="outline" className="text-green-500">
                              Ativo
                            </Badge>
                          )}
                        </div>
                        <p className="text-sm text-zinc-400">{announcement.message}</p>
                      </div>
                      <div className="flex gap-2">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() =>
                            toggleAnnouncementMutation.mutate({
                              id: announcement.id,
                              isActive: !announcement.isActive,
                            })
                          }
                        >
                          <Eye className="w-4 h-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => deleteAnnouncementMutation.mutate({ id: announcement.id })}
                        >
                          <Trash2 className="w-4 h-4 text-red-500" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Logs */}
          <TabsContent value="logs" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <Card className="bg-zinc-900 border-zinc-800">
                <CardHeader>
                  <CardTitle className="text-lg">Visitas (24h)</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-3xl font-bold text-red-600">{accessStats?.totalVisits || 0}</p>
                </CardContent>
              </Card>
              <Card className="bg-zinc-900 border-zinc-800">
                <CardHeader>
                  <CardTitle className="text-lg">IPs Únicos (24h)</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-3xl font-bold text-red-600">{accessStats?.uniqueIps || 0}</p>
                </CardContent>
              </Card>
              <Card className="bg-zinc-900 border-zinc-800">
                <CardHeader>
                  <CardTitle className="text-lg">Páginas Rastreadas</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-3xl font-bold text-red-600">{accessLogs?.length || 0}</p>
                </CardContent>
              </Card>
            </div>

            <Card className="bg-zinc-900 border-zinc-800">
              <CardHeader>
                <CardTitle>Logs de Acesso Recentes</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2 max-h-96 overflow-y-auto">
                  {accessLogs?.map((log) => (
                    <div key={log.id} className="p-2 bg-zinc-800 rounded text-sm">
                      <div className="flex items-center justify-between">
                        <span className="text-zinc-400">{log.ipAddress}</span>
                        <span className="text-zinc-500 text-xs">
                          {new Date(log.timestamp).toLocaleString("pt-BR")}
                        </span>
                      </div>
                      <p className="text-white">{log.path}</p>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Banimentos */}
          <TabsContent value="bans" className="space-y-6">
            <Card className="bg-zinc-900 border-zinc-800">
              <CardHeader>
                <CardTitle>Banir IP</CardTitle>
                <CardDescription>
                  IPs banidos não poderão acessar o site
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label>Endereço IP</Label>
                  <Input
                    value={banIpAddress}
                    onChange={(e) => setBanIpAddress(e.target.value)}
                    className="bg-zinc-800 border-zinc-700"
                    placeholder="Ex: 192.168.1.1"
                  />
                </div>
                <div className="space-y-2">
                  <Label>Motivo (opcional)</Label>
                  <Input
                    value={banReason}
                    onChange={(e) => setBanReason(e.target.value)}
                    className="bg-zinc-800 border-zinc-700"
                    placeholder="Ex: Tentativas de invasão"
                  />
                </div>
                <Button
                  onClick={() =>
                    banIpMutation.mutate({
                      ipAddress: banIpAddress,
                      reason: banReason || undefined,
                    })
                  }
                  disabled={!banIpAddress}
                  className="bg-red-600 hover:bg-red-700"
                >
                  <Ban className="w-4 h-4 mr-2" />
                  Banir IP
                </Button>
              </CardContent>
            </Card>

            <Card className="bg-zinc-900 border-zinc-800">
              <CardHeader>
                <CardTitle>IPs Banidos</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {bannedIps?.map((ban) => (
                    <div
                      key={ban.id}
                      className="flex items-center justify-between p-3 bg-zinc-800 rounded-lg"
                    >
                      <div>
                        <p className="font-mono font-medium">{ban.ipAddress}</p>
                        {ban.reason && (
                          <p className="text-sm text-zinc-400">{ban.reason}</p>
                        )}
                        <p className="text-xs text-zinc-500">
                          Banido em: {new Date(ban.bannedAt).toLocaleString("pt-BR")}
                        </p>
                      </div>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => unbanIpMutation.mutate({ ipAddress: ban.ipAddress })}
                        className="border-zinc-700"
                      >
                        Desbanir
                      </Button>
                    </div>
                  ))}
                  {bannedIps?.length === 0 && (
                    <p className="text-center text-zinc-500 py-8">Nenhum IP banido</p>
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
